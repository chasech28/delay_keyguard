#!/system/bin/sh

# Wait for 60 seconds
sleep 60
